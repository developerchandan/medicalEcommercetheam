<?php 
	/**
	Dashhoard footer
	*/
?>
	</div> <!-- .kapee-nav-tab-cnt-wrap -->
</div> <!-- .kapee-dashboard-wrap -->